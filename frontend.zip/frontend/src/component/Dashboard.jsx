import React, { useState, useEffect } from 'react';
import '../styles/Dashboard.scss'
import axios from 'axios';


function Body() {
  const [totalProducts, setTotalProducts] = useState(0);
  const [categoryCount, setCategoryCount] = useState(0);
  const [expiredProductCount, setExpiredProductCount] = useState(0);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const totalProductsResponse = await axios.get('http://localhost:3002/getProductCount');
      const categoryCountResponse = await axios.get('http://localhost:3002/getTotalType');
      const expiredProductCountResponse = await axios.get('http://localhost:3002/getExpiredProductCount');

      setTotalProducts(totalProductsResponse.data.productCount);
      setCategoryCount(categoryCountResponse.data.totalTypes);
      setExpiredProductCount(expiredProductCountResponse.data.expiredProductCount);
    } catch (error) {
      console.error('Error fetching data:', error.message);
    }
  };


  return (
    <div className="body-container">
      <div className="body-box">
        <h2>Total Products</h2>
        <p>{totalProducts}</p>
      </div>
      <div className="body-box">
        <h2>Categories</h2>
        <p>{categoryCount}</p>
      </div>
      <div className="body-box">
        <h2>Expired Products </h2>
        <p>{expiredProductCount}</p>
      </div>
    </div>
  );

  }

export default Body;
