import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../styles/Login.scss';


const Login = () => {
    const [formData, setFormData] = useState({
        email: '',
        password: '',
    });

    let navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;

        setFormData({
            ...formData,
            [name]: value,
        });
    };
    const handleSubmit = async (e) => {
        e.preventDefault();
    
        try {
            const body = formData.email.includes('@') ? { email: formData.email, password: formData.password } : { username: formData.email, password: formData.password };
    
            const response = await fetch('http://localhost:3003/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(body),
            });
    
            const data = await response.json();
    
            if (response.ok) {
                alert(data.message);
                navigate('/dashboard');
            } else {
                alert(data.message);
            }
        } catch (error) {
            alert('An error occurred. Please try again.');
        }
    };
    

    return (
      <div className="top">
         <video autoPlay loop muted className="background-video">
                {<source src="/background.mp4"/>}
         </video>
      <div className='welcome'>
      <h1>Welcome to ShopMart!!</h1>
      </div>
            <div className="custom-container1">
                <div className="custom-container1__content1">
                    <div className="custom-container1__content1__box1">
                    <div className="left-panel">
                    {<img src="/Food.png" alt="Profile" className="left-panel__image"/>}
                    <div className="vertical-stroke"></div>
                    </div>
                        <form onSubmit={handleSubmit}>
                            <div>
                                <h2 className='log'>Login</h2>
                            </div>
                            <div>
                                <label htmlFor='username'>User Name </label>
                                <input
                                    type='text'
                                    name='email'
                                    className='login-input'
                                    placeholder='Enter User Name / Email'
                                    value={formData.email}
                                    onChange={(e) => handleChange(e)}
                                    required
                                />
                            </div>
                            <div>
                                <label htmlFor='password'>Password</label>
                                <input
                                    type='password'
                                    name='password'
                                    className='login-input'
                                    placeholder='Enter Password'
                                    value={formData.password}
                                    onChange={(e) => handleChange(e)}
                                    required
                                />
                            </div>
                            <div>You are agreed to our terms and policies</div>

                            <div>
                                <button className="login" type='submit' value="login">Login</button>
                                
                            </div>
                            <div>
                                <Link to="/forgot"><button className="forgot">Forgot Password</button></Link>
                            </div>
                            <div>
                                <Link to="/signup"><button className="signAccount" value="sign">Create Account</button></Link>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Login;
