import React, { useEffect, useState } from 'react';
import axios from 'axios';
import '../styles/ProductList.scss';
import {Link} from 'react-router-dom';

const ProductList = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    try {
      const response = await axios.get('http://localhost:3002/getProducts');
      setProducts(response.data);
    } catch (error) {
      console.error('Error fetching products:', error.message);
    }
  };

  const deleteProduct = async (id) => {
    const userChoice = window.prompt(
      "Select an option to delete this product:\n\n1. Delete from Database\n2. Delete from Page Only\n",
      "1"
    );
  
    if (userChoice === "1") {
      const confirmDelete = window.confirm("Are you sure you want to delete this product from the database?");
      if (confirmDelete) {
        try {
          await axios.delete(`http://localhost:3002/deleteProduct/${id}`);
          loadProducts();
        } catch (error) {
          console.error("Error deleting invoice:", error);
        }
      }
    } else if (userChoice === "2") {
      setProducts((prevProducts) =>
        prevProducts.filter((product) => product.product_id !== id)
      );
    } else {
      // Cancel deletion
      return;
    }
  };

  const formatDateString = (dateString) => {
    const dateObject = new Date(dateString);
    const year = dateObject.getFullYear();
    const month = (dateObject.getMonth() + 1).toString().padStart(2, '0');
    const day = dateObject.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
  };
  
  
  return (
    <div>
      <h2 className="header">Product List</h2>
      <Link to="/add"><button className="addbutton">+Add Product</button></Link>
      <div>
        <div>
        <div>
          <table className="table">
            <thead>
              <tr>
                <th scope="col">Serial_No</th>
                <th scope="col">Product ID</th>
                <th scope="col">Product Name</th>
                <th scope="col">Exp Date</th>
                <th scope="col">Purchase Cost</th>
                <th scope="col">Margin</th>
                <th scope="col">Tax</th>
                <th scope="col">Selling Price</th>
                <th scope="col">Photo</th>
                <th scope="col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {products.map((product, index) => (
              <tr key={product.product_id}>
              <td>{index + 1}</td> 
              <td>{product.product_id}</td>
              <td>{product.product_name}</td>
              <td>{product.exp_date ? formatDateString(product.exp_date) : ''}</td>
              <td>{product.purchase_cost}</td>
              <td>{product.margin}</td>
              <td>{product.tax}</td>
              <td>{product.selling_price}</td>
              <td><img src={product.photo} alt="Photo" /></td>
              <td>
              <Link to={`/view/${product.product_id}`}><button className="button view-button" value="VIEW">View</button></Link>
              <Link to={`/edit/${product.product_id}`}>
              <button className="button edit-button" value="EDIT">Edit</button>
              </Link>
              <button className="button delete-button" value="DELETE" onClick={() => deleteProduct(product.product_id)}>Delete</button>
            </td>
           </tr>
            ))}
          </tbody>

          </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductList;
