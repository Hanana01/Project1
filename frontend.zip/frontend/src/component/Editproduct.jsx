import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';
import '../styles/Editproduct.scss';

const EditProduct = () => {
  let navigate = useNavigate();
  const { product_id } = useParams();
  const [formattedDate, setFormattedDate] = useState('');
  const [errors, setErrors] = useState({});

  const [formData, setFormData] = useState({
    product_name: '',
    exp_date: '',
    weight: '',
    brand: '',
    type: '',
    purchase_cost: '',
    margin: '',
    tax: '',
    selling_price: '',
    photo: '',
    photo1: '',
    photo2: '',
    photo3: '',
    photo4: '',
  });

  const { product_name, type, weight, brand, purchase_cost, margin, tax, selling_price, photo, photo1, photo2, photo3, photo4 } = formData;

  const handleChange = (e) => {
    const { name, value } = e.target;
  
    if (name === 'exp_date') {
      const dateObject = new Date(value);
      const formattedExpDate = `${dateObject.getFullYear()}-${(dateObject.getMonth() + 1).toString().padStart(2, '0')}-${dateObject.getDate().toString().padStart(2, '0')}`;
      setFormattedDate(formattedExpDate);
    }
  
    setFormData({
      ...formData,
      [name]: value,
    });
  };
  

  useEffect(() => {
    const fetchProductData = async () => {
      try {
        const response = await axios.get(`http://localhost:3002/getProduct/${product_id}`);
        const productData = response.data;
        setFormData(productData);
        const dateObject = new Date(productData.exp_date);
        const formattedExpDate = `${dateObject.getFullYear()}-${(dateObject.getMonth() + 1).toString().padStart(2, '0')}-${dateObject.getDate().toString().padStart(2, '0')}`;
        setFormattedDate(formattedExpDate);
      } catch (error) {
        console.error('Error fetching product data:', error);
      }
    };

  
    fetchProductData();
  }, [product_id]);
  

  const onSubmit = async (e) => {
    e.preventDefault();
    const formErrors = validate();
    if (Object.keys(formErrors).length === 0) {
      try {
        await axios.put(`http://localhost:3002/updateProduct/${product_id}`, formData);
        navigate('/product');
      } catch (error) {
        console.error('Error updating product:', error);
      }
    } else {
      setErrors(formErrors);
    }
  };

  const validate = () => {
    const errors = {};
    const sellingpriceValue = parseFloat(formData.selling_price);
    const marginValue = parseInt(formData.margin, 10);

    if (formData.weight <= 0) {
      errors.weight = 'Weight should be greater than zero';
    }
    if (formData.purchase_cost <= 0) {
      errors.purchasecost = 'Purchase Cost should be greater than zero';
    }
    if (isNaN(marginValue) || marginValue <= 0) {
      errors.margin = 'Margin should be a positive integer';
    }
    if (formData.tax <= 0) {
      errors.tax = 'Tax should be greater than zero';
    }
    if (sellingpriceValue <= formData.purchase_cost) {
      errors.sellingprice = 'Selling Price should be greater than Purchase Cost';
    }
    return errors;
  };

  return (
    <div>
      <h2 className="header">Edit Product</h2>
      <div className="custom-container">
        <div className="custom-container__content">
          <div className="custom-container__content__box border-rounded">
            <form onSubmit={onSubmit}>
              <div>
                <h4>Details</h4>
                <hr />
              </div>
              <div>
                <label htmlFor="name">Product Name: </label>
                <input
                  type="text"
                  id="name"
                  name="product_name"
                  value={product_name}
                  onChange={handleChange}
                  required
                />
              </div>

              <div>
                <label htmlFor="expdate">Expired Date: </label>
                <input
                  type="date"
                  name="exp_date"
                  value= {formattedDate}
                  onChange={handleChange}
                  required
                />
              </div>

              <div>
                <label htmlFor="weight">Weight(kg / l): </label>
                <input
                  type="number"
                  name="weight"
                  value={weight}
                  onChange={handleChange}
                  required
                />
                {errors.weight && <span style={{ color: 'red', fontSize: '10px' }}>{errors.weight}</span>}
              </div>

              <div>
                <label htmlFor="brand">Brand: </label>
                <input
                  type="text"
                  name="brand"
                  value={brand}
                  onChange={handleChange}
                  required
                />
              </div>

              <div>
                <label htmlFor="type">Type: </label>
                <input
                  type="text"
                  name="type"
                  value={type}
                  onChange={handleChange}
                  required
                />
              </div>

              <div>
                <label htmlFor="purchasecost">Purchase Cost: </label>
                <input
                  type="number"
                  name="purchase_cost"
                  value={purchase_cost}
                  onChange={handleChange}
                  required
                />
                {errors.purchasecost && (
                  <span style={{ color: 'red', fontSize: '10px' }}>{errors.purchasecost}</span>
                )}
              </div>

              <div>
                <label htmlFor="margin">Margin: </label>
                <input
                  type="number"
                  name="margin"
                  value={margin}
                  onChange={handleChange}
                  required
                />
                {errors.margin && <span style={{ color: 'red', fontSize: '10px' }}>{errors.margin}</span>}
              </div>

              <div>
                <label htmlFor="tax">Tax: </label>
                <input
                  type="number"
                  name="tax"
                  value={tax}
                  onChange={handleChange}
                  required
                />
                {errors.tax && <span style={{ color: 'red', fontSize: '10px' }}>{errors.tax}</span>}
              </div>

              <div>
                <label htmlFor="sellingprice">Selling Price: </label>
                <input
                  type="number"
                  name="selling_price"
                  value={selling_price}
                  onChange={handleChange}
                  required
                />
                {errors.sellingprice && (
                  <span style={{ color: 'red', fontSize: '10px' }}>{errors.sellingprice}</span>
                )}
              </div>

              <div>
                <label htmlFor="photo">Photo: </label>
                <input
                  type="text"
                  name="photo"
                  value={photo}
                  onChange={handleChange}
                />
              </div>

              <div>
                <label htmlFor="photo1">Photo1: </label>
                <input
                  type="text"
                  name="photo1"
                  value={photo1}
                  onChange={handleChange}
                />
              </div>

              <div>
                <label htmlFor="photo2">Photo2: </label>
                <input
                  type="text"
                  name="photo2"
                  value={photo2}
                  onChange={handleChange}
                />
              </div>

              <div>
                <label htmlFor="photo3">Photo3: </label>
                <input
                  type="text"
                  name="photo3"
                  value={photo3}
                  onChange={handleChange}
                />
              </div>

              <div>
                <label htmlFor="photo4">Photo4: </label>
                <input
                  type="text"
                  name="photo4"
                  value={photo4}
                  onChange={handleChange}
                />
              </div>

              <div className="buttonstyle">
              <button type="submit" value="update">
               Update
              </button>
              <button className="cancelButton" type="button" value="Cancel" onClick={() => navigate('/product')}>
               Cancel
              </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditProduct;
