import React from 'react';
import '../styles/Navbar.scss';
import { FaBars } from 'react-icons/fa';
import { Link } from 'react-router-dom';

function Navbar({ onMenuClick }) {
  return (
    <nav className="navbar">
      <div className="left-section">
        <div>
          <img src="/Logo.png" className="companylogo" alt="Company Logo" />
        </div>
        <div className="logo" onClick={onMenuClick}>
          <FaBars />
        </div>

        <div className="name">
          <h4>ShopMart</h4>
        </div>

      </div>
      <div className="right-section">
        <div className="navbar-actions">
          <div className="search-bar">
            <input type="text" placeholder="Search..." />
          </div>
          <Link to="/login">
            <button className="logout-button">Logout</button>
          </Link>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
