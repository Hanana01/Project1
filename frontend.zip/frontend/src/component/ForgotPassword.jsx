import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/ForgotPassword.scss';


function ForgotPassword() {
  return (
    <div className="top">
        <video autoPlay loop muted className="background-video">
                {<source src="/background.mp4"/>}
         </video>

    <div className='welcome'>
    <h1>Welcome to ShopMart!!</h1>
    </div>
          <div className="custom-container3">
              <div className="custom-container3__content3">
                  <div className="custom-container3__content3__box3">
                  <div className="left-panel">
                  {<img src="/Food.png" alt="Profile" className="left-panel__image"/>}
                  <div className="vertical-stroke"></div>
                  </div>
        <form action=''>
            <div>
            <h2 className='set'>Set Password</h2>
            </div>
            <div>
                <label htmlFor='email'>Email</label>
                <input type='email' name='email' className='login-input' placeholder='Enter Email' required/>   
            </div>
            <div>
                <label htmlFor='password'>Password</label>
                <input type='password' name='password' className='login-input' placeholder='Enter Password' required/>   
            </div>
            <div>
                <button className="setpassword" type='submit' value="setpassword">Set Password</button>
            </div>
            <div>
                 <Link to="/login"><button className="back" type='submit' value="sign">Back</button></Link>
            </div>
        </form>
        </div>
        </div>
        </div>
</div>
  )
}

export default ForgotPassword