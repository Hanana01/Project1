import React, { useState } from 'react';
import axios from 'axios';
import '../styles/Signup.scss';
import { Link, useNavigate} from 'react-router-dom';


const Signup = () => {
  let navigate = useNavigate();

  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const validate = () => {
    const errors = {};

    if (!formData.email) {
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errors.email = "Invalid email address";
    }

    if (!formData.password) {
    } else if (formData.password.length < 6) {
      errors.password = "Password must be at least 6 characters";
    }

    return errors;
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    const formErrors = validate();
    if (Object.keys(formErrors).length === 0) {
        await axios.post('http://localhost:3003/addUser', formData);
        alert('User signed up successfully!');
        navigate('/dashboard');
      } else {
        setErrors(formErrors);
      }
  };

  return (
    <div className="top">
      <video autoPlay loop muted className="background-video">
                {<source src="/background.mp4"/>}
         </video>

      <div className='welcome'>
      <h1>Welcome to ShopMart!!</h1>
      </div>
            <div className="custom-container2">
                <div className="custom-container2__content2">
                    <div className="custom-container2__content2__box2">
                    <div className="left-panel">
                    {<img src="/Food.png" alt="Profile" className="left-panel__image"/>}
                    <div className="vertical-stroke"></div>
                    </div>
            <form onSubmit={onSubmit}>
              <div>
              <h2 className='sign'>Sign Up</h2>
              </div>
              <div>
                <label htmlFor='username'>User Name</label>
                <input
                  type='text'
                  name='username'
                  className='login-input'
                  value={formData.username}
                  placeholder='Enter Name'
                  onChange={(e) => handleChange(e)}
                  required
                />
                {errors.username && <span style={{ color: "red", fontSize: "12px" }}>{errors.username}</span>}
              </div>
              <div>
                <label htmlFor='email'>Email</label>
                <input
                  type='email'
                  name='email'
                  className='login-input'
                  value={formData.email}
                  placeholder='Enter Email'
                  onChange={(e) => handleChange(e)}
                  required
                />
                {errors.email && <span style={{ color: "red", fontSize: "12px" }}>{errors.email}</span>}
              </div>
              <div>
                <label htmlFor='password'>Password</label>
                <input
                  type='password'
                  name='password'
                  className='login-input'
                  value={formData.password}
                  placeholder='Enter Password'
                  onChange={(e) => handleChange(e)}
                  required
                />
                {errors.password && <span style={{ color: "red", fontSize: "12px" }}>{errors.password}</span>}
              </div>
              <div>
                You are agreed to our terms and policies
              </div>
              <div>
                <button className="signButton" type='submit' value="signup">Sign Up</button>
              </div>
              <div>
                <Link to="/login"><button className="loginButton" value="login">Login</button></Link>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Signup;
