import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';
import '../styles/Viewproduct.scss';

const ViewProduct = () => {
  const { product_id } = useParams();
  const [product, setProduct] = useState({});
  const [formattedDate, setFormattedDate] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProductData = async () => {
      try {
        const response = await axios.get(`http://localhost:3002/getProduct/${product_id}`);
        const productData = response.data;
        setProduct(productData);
        const dateObject = new Date(productData.exp_date);
        const formattedExpDate = `${dateObject.getFullYear()}-${(dateObject.getMonth() + 1)
          .toString()
          .padStart(2, '0')}-${dateObject.getDate().toString().padStart(2, '0')}`;
        setFormattedDate(formattedExpDate);
      } catch (error) {
        console.error('Error fetching product data:', error);
      }
    };

    fetchProductData();
  }, [product_id]);

  return (
    <div>
      <h2 className="header">View Product</h2>
      <div className="custom-container">
        <div className="custom-container__content">
          <div className="custom-container__content__box border-rounded">
            <div>
              <ol>
                <li>Product ID : {product.product_id}</li>
                <li>Product Name : {product.product_name}</li>
                <li>Expired Date : {formattedDate}</li>
                <li>Weight(kg/l) : {product.weight}</li>
                <li>Brand : {product.brand}</li>
                <li>Type : {product.type}</li>
                <li>Margin : {product.margin}</li>
                <li>Purchase Cost(Rs.) : {product.purchase_cost}</li>
                <li>Tax(Rs.) : {product.tax}</li>
                <li>Selling Price(Rs.) : {product.selling_price}</li>
                <li>Photos </li>
              </ol>
              <button className="Button" type="button" onClick={() => navigate('/product')}>
                Go Back
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ViewProduct;
