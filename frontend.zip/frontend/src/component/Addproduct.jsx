import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from "react-router-dom";
import '../styles/Addproduct.scss';


const Addproduct = () => {
  let navigate = useNavigate();

  const [errors, setErrors] = useState({});

  const [formData, setFormData] = useState({
    name: '',
    expdate: '',
    weight: 0,
    brand: '',
    type: '',
    purchasecost: 0,
    margin: 0,
    tax: 0,
    sellingprice: 0,
    photo: '',
    photo1: '',
    photo2: '',
    photo3: '',
    photo4: '',
  });

  const {name, type, weight, expdate, brand, purchasecost, margin, tax, sellingprice, photo, photo1, photo2, photo3, photo4} = formData

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const validate = () => {
    const errors = {};
    const sellingpriceValue = parseFloat(formData.sellingprice);
    const marginValue = parseInt(formData.margin, 10); // Parse to integer

    if (formData.weight <= 0) {
      errors.weight = "Weight should be greater than zero";
    }
    if (formData.purchasecost <= 0) {
      errors.purchasecost = "Purchase Cost should be greater than zero";
    }
    if (isNaN(marginValue) || marginValue <= 0) {
    errors.margin = "Margin should be a positive integer";
    }
    if (formData.tax <= 0) {
      errors.tax = "Tax should be greater than zero";
    }
    if (sellingpriceValue <= formData.purchasecost) {
      errors.sellingprice = "Selling Price should be greater than Purchase Cost";
    }
    return errors;
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    const formErrors = validate();
    if (Object.keys(formErrors).length === 0) {
      await axios.post('http://localhost:3002/addProduct', formData);
      navigate('/product');
    } else {
      setErrors(formErrors);
    }
  };

  return (
    <div>
      <h2 className="header">Add Products</h2>
      <div className="custom-container">
      <div className="custom-container__content">
        <div className="custom-container__content__box border-rounded">
          <form onSubmit={(e) => onSubmit(e)}>
            <div>
              <h4>Details</h4><hr/>
            </div>
            <div>
            <label htmlFor="name">Product Name: </label>
            <input
            type="text"
            id="name"
            name="name"
            value={name}
            onChange = {(e) => handleChange(e)}
            required
            />
            </div>

            <div>
              <label htmlFor='expdate'>Expired Date: </label>
              <input
              type='date'
              name='expdate'
              value={expdate}
              onChange = {(e) => handleChange(e)}
              required
              />
            </div>

            <div>
              <label htmlFor="weight">Weight(kg / l): </label>
              <input
              type='number'
              name='weight'
              value={weight}
              onChange = {(e) => handleChange(e)}
              required
              />
              {errors.weight && <span style={{ color: "red", font: "10px" }}>{errors.weight}</span>}
            </div>

            <div>
              <label htmlFor='brand'>Brand: </label>
              <input
              type='text'
              name='brand'
              value={brand}
              onChange = {(e) => handleChange(e)}
              required
              />
            </div>

            <div>
            <label htmlFor="type">Type: </label>
            <input
            type="text"
            name="type"
            value={type}
            onChange = {(e) => handleChange(e)}
            required
            />
            </div>

            <div>
              <label htmlfor='purchasecost'>Purchase Cost: </label>
              <input 
              type='number'
              name='purchasecost'
              value={purchasecost}
              onChange = {(e) => handleChange(e)}
              required
              /> 
              {errors.purchasecost && <span style={{ color: "red", font: "10px" }}>{errors.purchasecost}</span>}
            </div>

            <div>
              <label htmlfor='margin'>Margin: </label>
              <input 
              type='number'
              name='margin'
              value={margin}
              onChange = {(e) => handleChange(e)}
              required
              /> 
              {errors.margin && <span style={{ color: "red", font: "10px" }}>{errors.margin}</span>}
            </div>

            <div>
              <label htmlfor='tax'>Tax: </label>
              <input 
              type='number'
              name='tax'
              value={tax}
              onChange = {(e) => handleChange(e)}
              required
              /> 
              {errors.tax && <span style={{ color: "red", font: "10px" }}>{errors.tax}</span>}
            </div>

            <div>
              <label htmlfor='sellingprice'>Selling Price: </label>
              <input 
              type='number'
              name='sellingprice'
              value={sellingprice}
              onChange = {(e) => handleChange(e)}
              required
              /> 
              {errors.sellingprice && <span style={{ color: "red", font: "10px" }}>{errors.sellingprice}</span>}
            </div>

            <div>
              <label htmlfor='photo'>Photo: </label>
              <input 
              type='text'
              name='photo'
              value={photo}
              onChange = {(e) => handleChange(e)}
             
              /> 
            </div>

            <div>
              <label htmlfor='photo1'>Photo1: </label>
              <input 
              type='text'
              name='photo1'
              value={photo1}
              onChange = {(e) => handleChange(e)}
              /> 
            </div>

            <div>
              <label htmlfor='photo2'>Photo2: </label>
              <input 
              type='text'
              name='photo2'
              value={photo2}
              onChange = {(e) => handleChange(e)}
              /> 
            </div>

            <div>
              <label htmlfor='photo3'>Photo3: </label>
              <input 
              type='text'
              name='photo3'
              value={photo3}
              onChange = {(e) => handleChange(e)}
              /> 
            </div>

            <div>
              <label htmlfor='photo4'>Photo4: </label>
              <input 
              type='text'
              name='photo4'
              value={photo4}
              onChange = {(e) => handleChange(e)}
              /> 
            </div>

            <div className="buttonstyle">
              <button type="submit" value="add">
               Add
              </button>
              <button className="cancelButton" type="button" value="Cancel" onClick={() => navigate('/product')}>
               Cancel
              </button>
            </div>

          </form>
        </div>
      </div>
    </div> 
    </div>
  )
}

export default Addproduct;