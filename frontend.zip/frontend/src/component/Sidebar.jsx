// Sidebar.js
import React from 'react';
import { NavLink } from 'react-router-dom';
import { FaHome, FaShoppingCart, FaUser, FaClipboardList, FaFileInvoice, FaCog } from 'react-icons/fa';
import '../styles/Sidebar.scss';

function Sidebar({ isVisible }) {
  return (
    <div className={`sidebar ${isVisible ? 'visible' : ''}`}>
      <NavLink to="/dashboard" activeClassName="active">
        <FaHome className="icon" />
        Dashboard
      </NavLink>
      <NavLink to="/product" activeClassName="active">
        <FaShoppingCart className="icon" />
        Products
      </NavLink>
      <NavLink to="/customer" activeClassName="active">
        <FaUser className="icon" />
        Customers
      </NavLink>
      <NavLink to="/order" activeClassName="active">
        <FaClipboardList className="icon" />
        Orders
      </NavLink>
      <NavLink to="/invoice" activeClassName="active">
        <FaFileInvoice className="icon" />
        Invoices
      </NavLink>
      <NavLink to="/settings" activeClassName="active">
        <FaCog className="icon" />
        Settings
      </NavLink>
    </div>
  );
}

export default Sidebar;
