import React, { useState } from 'react';
import Navbar from './component/Navbar';
import Dashboard from './component/Dashboard';
import Sidebar from './component/Sidebar';
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import ProductList from './component/ProductList';
import Addproduct from './component/Addproduct';
import Editproduct from './component/Editproduct';
import Viewproduct from './component/Viewproduct';
import Login from './component/Login';
import Signup from './component/Signup';
import ForgotPassword from './component/ForgotPassword';





function App() {
  const [sidebarVisible, setSidebarVisible] = useState(false);
  const toggleSidebar = () => {
    setSidebarVisible(!sidebarVisible);
};
return (
    <div>
      <Router>
         
         <Sidebar isVisible={sidebarVisible} />
         <Navbar onMenuClick={toggleSidebar} />
        
       <Routes>
       <Route exact path="/product" element={<ProductList/>} />
       <Route exact path="/dashboard" element={<Dashboard/>} />
       <Route exact path="/add" element={<Addproduct />} />
       <Route exact path="/edit/:product_id" element={<Editproduct />} />
       <Route exact path="/view/:product_id" element={<Viewproduct />} />
       <Route exact path="/signup" element={<Signup />} />
       <Route exact path="/login" element={<Login />}  />
       <Route exact path="/forgot" element={<ForgotPassword />} />
       </Routes>
       
       </Router>
    </div>
  );
}

export default App;
